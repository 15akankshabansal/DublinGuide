package com.example.most.dublinguide;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.util.LruCache;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;

public class CustomRequest {
    private static CustomRequest rInstance;
    private RequestQueue requestQueue;
    private static Context mContext;
    private ImageLoader mImageLoader;

    private CustomRequest(){
        requestQueue = Volley.newRequestQueue(mContext.getApplicationContext());
        mImageLoader = new ImageLoader(this.requestQueue, new ImageLoader.ImageCache() {
            private final LruCache<String, Bitmap> mCache = new LruCache<String, Bitmap>(10);
            public void putBitmap(String url, Bitmap bitmap) {
                mCache.put(url, bitmap);
            }
            public Bitmap getBitmap(String url) {
                return mCache.get(url);
            }
        });
    }

    public CustomRequest(Context context) {
        mContext = context;
        requestQueue = getRequestQueue();
    }

    public RequestQueue getRequestQueue(){
        if(requestQueue==null){
            requestQueue = Volley.newRequestQueue(mContext.getApplicationContext());
        }
        return requestQueue;
    }

    public ImageLoader getImageLoader(){
        return this.mImageLoader;
    }
    public static synchronized CustomRequest getrInstance(Context context){
        if(rInstance == null){
            rInstance = new CustomRequest(context);
        }
        return rInstance;
    }
    public <T> void addToRequestQue(Request<T> request){
        requestQueue.add(request);
    }
}
