package com.example.most.dublinguide;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

import java.util.ArrayList;

public class HotelAdapter extends BaseAdapter {
    ArrayList<String> vHotelname;
    ArrayList<String>vUrl;
    ArrayList<String>vInfo;
    ArrayList<String>vAddress;
    ArrayList<String>vContact;
    ArrayList<String>vWebsite;

    Main2Activity context;
    TextView tv1,tv2,tv3, tv4, tv5;
    NetworkImageView iv2;


    public HotelAdapter(Main2Activity m1, ArrayList<String> hotelname, ArrayList<String> address, ArrayList<String> contact, ArrayList<String> website, ArrayList<String> url, ArrayList<String> info) {
        context = m1;
        this.vHotelname = hotelname;
        this.vAddress = address;
        this.vContact = contact;
        this.vWebsite = website;
        this.vInfo = info;
        this.vUrl = url;
    }

    @Override
    public int getCount() {
        return vHotelname.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }




    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        view = context.getLayoutInflater().inflate(R.layout.custom1, null);

        tv1 = (TextView)view.findViewById(R.id.textView1);
        tv2 = (TextView)view.findViewById(R.id.textView2);
        tv3 = (TextView)view.findViewById(R.id.textView3);
        tv4 = (TextView)view.findViewById(R.id.textView4);
        tv5 = (TextView)view.findViewById(R.id.textView5);
        iv2 = (NetworkImageView)view.findViewById(R.id.imageView2);

        tv1.setText(vHotelname.get(i));
        tv2.setText(vInfo.get(i));
        tv5.setText(vWebsite.get(i));
        tv3.setText(vAddress.get(i));
        tv4.setText(vContact.get(i));

        ImageLoader imageLoader = CustomRequest.getrInstance(context).getImageLoader();
        iv2.setImageUrl(vUrl.get(i),imageLoader);
//        NoUnderlineSpan obj = new NoUnderlineSpan();
//
//        if (call.getText() instanceof Spannable) {
//            Spannable s = (Spannable) call.getText();
//            s.setSpan(obj, 0, s.length(), Spanned.SPAN_MARK_MARK);
//        }

        return view;
    }
}
