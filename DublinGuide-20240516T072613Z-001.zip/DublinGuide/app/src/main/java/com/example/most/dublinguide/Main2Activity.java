package com.example.most.dublinguide;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    ListView lv;
    String Json_Link = "https://api.myjson.com/bins/1f0x62";
    ArrayList<String> hotelname = new ArrayList<>();
    ArrayList<String> address = new ArrayList<>();
    ArrayList<String> contact = new ArrayList<>();
    ArrayList<String> website = new ArrayList<>();
    ArrayList<String> info = new ArrayList<>();
    ArrayList<String> url = new ArrayList<>();
    Boolean flag=true;

    ArrayAdapter<String> adapter;
    HotelAdapter madapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);



        lv = (ListView) findViewById(R.id.listView);
        this.setTitle("Hotels");

        madapter = new HotelAdapter(this, hotelname,address,contact,website,url,info);
        lv.setAdapter(adapter);
        registerForContextMenu(lv);
        jsondata();

    }

    public  void jsondata()
    {

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, Json_Link,null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray =response.getJSONArray("Hotels");

                            for(int i=0;i<jsonArray.length();i++)
                            {
                                JSONObject jsonObject =jsonArray.getJSONObject(i);
              //                hotelname.add((String) JSONParser.getJsonFeildValue(response.toString(), "hotelname"));

                                                     hotelname.add(jsonObject.getString("hotelname"));
                                address.add(jsonObject.getString("address"));
                                contact.add(jsonObject.getString("contact"));
                                website.add(jsonObject.getString("website"));
                                url.add(jsonObject.getString("url"));
                                info.add(jsonObject.getString("info"));

                            }
                            if(hotelname.size() > 0)
                            {
                              flag = false;
                            }
                            HotelAdapter adapter = new HotelAdapter(Main2Activity.this,hotelname,address,contact,website,url,info);
                            lv.setAdapter(adapter);
                            registerForContextMenu(lv);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        CustomRequest.getrInstance(Main2Activity.this).addToRequestQue(jsonObjectRequest);
    }



    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Open with Phone");
        menu.add(0,0,0,"Just Once");
        menu.add(0,0,0,"Always");
        menu.setHeaderTitle("Use a different app");
        menu.add(0,0,0,"Skype");
    }

    public boolean onContextItemSelected(MenuItem item){
        if(item.getTitle().equals("Just Once")){
            Uri number = Uri.parse("tel:123456789");
            Intent callIntent = new Intent(Intent.ACTION_DIAL, number);
            startActivity(callIntent);
            return true;
        }else if(item.getTitle().equals("Always")){
            Uri number = Uri.parse("tel:123456789");
            Intent callIntent = new Intent(Intent.ACTION_DIAL, number);
            startActivity(callIntent);
            return true;
        }else{
            return false;
        }
    }
}


