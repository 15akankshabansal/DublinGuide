package com.example.most.dublinguide;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JSONParser
{
    public static Object parseJSON(String s) throws JSONException {
        if (s.trim().startsWith("{")) {
            return new JSONObject(s);
        }
        else if (s.trim().startsWith("[")) {
            return new JSONArray(s);
        }
        throw new JSONException("Unparsable JSON string: " + s);
    }

    public static Object getJsonFeildValue(String jsonString, String field) throws JSONException {
        JSONObject jsonObject = new JSONObject(jsonString);
        Object object = jsonObject.get(field);
        return object;

    }
}

